Upgrade platformdirs to 4.3.6
