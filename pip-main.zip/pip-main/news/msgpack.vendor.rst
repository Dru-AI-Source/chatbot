Upgrade msgpack to 1.1.0
