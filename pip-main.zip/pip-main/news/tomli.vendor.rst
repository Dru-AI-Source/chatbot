Upgrade tomli to 2.2.1
