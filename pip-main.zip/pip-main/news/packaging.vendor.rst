Upgrade packaging to 24.2
