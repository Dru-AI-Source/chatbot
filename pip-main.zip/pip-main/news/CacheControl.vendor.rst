Upgrade CacheControl to 0.14.1
