Upgrade rich to 13.9.4
